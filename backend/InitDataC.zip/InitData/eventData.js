import event from '../models/Event.js';
import mongoose from "mongoose";

const data = [
  {
    "title": "Full Stack Mastery Workshop",
    "description": "A deep dive into MERN stack development with hands-on projects.",
    "date": "2026-03-15T10:00:00.000Z",
    "location": "Main Auditorium, Block C",
    "maxAttendees": 100,
    "createdBy": "user_98765",
    "course": "Computer Science",
    "organization": "Tech University",
    "category": "Workshop",
    "visibility": "Open to all within Organization",
    "eventFileUrl": "https://storage.provider.com/events/flyer-fs.pdf"
  },
  {
    "title": "Annual Cultural Fest 2026",
    "description": "The biggest cultural celebration of the year featuring music and dance.",
    "date": "2026-04-20T18:00:00.000Z",
    "location": "Open Ground",
    "maxAttendees": 2000,
    "createdBy": "admin_dept_01",
    "course": "General",
    "organization": "Tech University",
    "category": "Fest",
    "visibility": "Open to All",
    "eventFileUrl": "https://storage.provider.com/events/fest-guide.pdf"
  },
  {
    "title": "Intro to Quantum Computing",
    "description": "An introductory webinar for beginners curious about qubits.",
    "date": "2026-02-10T15:30:00.000Z",
    "location": "Zoom Meeting",
    "maxAttendees": 500,
    "createdBy": "prof_smith_44",
    "course": "Physics",
    "organization": "Global Science Academy",
    "category": "Webinar",
    "visibility": "Open to All",
    "eventFileUrl": "https://storage.provider.com/events/webinar-link.pdf"
  },
  {
    "title": "Freshers Orientation 2026",
    "description": "Welcome session for the new batch of MBA students.",
    "date": "2026-08-01T09:00:00.000Z",
    "location": "Seminar Hall 2",
    "maxAttendees": 120,
    "createdBy": "coord_hr",
    "course": "MBA",
    "organization": "Business School of Excellence",
    "category": "Orientation",
    "visibility": "Only within Same Course",
    "eventFileUrl": "https://storage.provider.com/events/orientation-schedule.pdf"
  },
  {
    "title": "AI Ethics Debate",
    "description": "A discussion on the ethical implications of AGI in modern society.",
    "date": "2026-05-12T14:00:00.000Z",
    "location": "Library Room 4",
    "maxAttendees": 50,
    "createdBy": "student_lead_ai",
    "course": "Computer Science",
    "organization": "Tech University",
    "category": "Other",
    "visibility": "Only within Same Course",
    "eventFileUrl": "https://storage.provider.com/events/debate-rules.pdf"
  },
  {
    "title": "Advanced Data Structures Session",
    "description": "Solving LeetCode hard problems on Graphs and Trees.",
    "date": "2026-02-28T11:00:00.000Z",
    "location": "Lab 302",
    "maxAttendees": 30,
    "createdBy": "tutor_jane",
    "course": "Computer Science",
    "organization": "Tech University",
    "category": "Workshop",
    "visibility": "Open to all within Organization",
    "eventFileUrl": "https://storage.provider.com/events/ds-handout.pdf"
  },
  {
    "title": "Cyber Security Awareness Talk",
    "description": "Learn how to protect your digital identity from phishing attacks.",
    "date": "2026-03-05T13:00:00.000Z",
    "location": "Online - MS Teams",
    "maxAttendees": 0,
    "createdBy": "it_security_dept",
    "course": "Cyber Security",
    "organization": "City College",
    "category": "Webinar",
    "visibility": "Open to All",
    "eventFileUrl": "https://storage.provider.com/events/security-checklist.pdf"
  }
]

const dburl = 'mongodb://127.0.0.1:27017/Alumni';

const saveDate = async()=>{
    try{
        await mongoose.connect(dburl);
        console.log("✅ MongoDB Connected");

        await event.insertMany(data);
        console.log("All data inserted");

        process.exit();
    }catch(err){
        console.log(err);
    }
}

saveDate();
import internship from '../models/Internship.js';
import mongoose from "mongoose";

const data = [
  {
    "title": "MERN Stack Developer Intern",
    "description": "Work on full-stack web development using MongoDB, Express, React, and Node.js. Build REST APIs and responsive UI.",
    "skills": "Web Dev",
    "company": "TechNova Solutions",
    "location": "Remote",
    "stipend": "₹10,000/month",
    "duration": "3 Months",
    "postedBy": "65f1a1c2b4a1234567890001",
    "applicants": []
  },
  {
    "title": "Frontend Developer Intern",
    "description": "Develop user-friendly interfaces using React.js and Material UI. Collaborate with designers and backend developers.",
    "skills": "Web Dev",
    "company": "UIX Labs",
    "location": "Bangalore, India",
    "stipend": "₹8,000/month",
    "duration": "2 Months",
    "postedBy": "65f1a1c2b4a1234567890004",
    "applicants": []
  },
  {
    "title": "Backend Developer Intern",
    "description": "Build scalable backend services using Node.js, Express, and MongoDB. Handle authentication and database design.",
    "skills": "Web Dev",
    "company": "CloudCore Pvt Ltd",
    "location": "Delhi, India",
    "stipend": "₹12,000/month",
    "duration": "6 Months",
    "postedBy": "65f1a1c2b4a1234567890006",
    "applicants": []
  },
  {
    "title": "Machine Learning Intern",
    "description": "Work on data preprocessing, model training, and evaluation using Python, NumPy, Pandas, and Scikit-learn.",
    "skills": "ML",
    "company": "AI Innovators",
    "location": "Remote",
    "stipend": "₹15,000/month",
    "duration": "4 Months",
    "postedBy": "65f1a1c2b4a1234567890007",
    "applicants": []
  },
  {
    "title": "Software Engineering Intern",
    "description": "Assist in software development, debugging, and testing. Gain hands-on experience with real-world projects.",
    "skills": "Software Eng.",
    "company": "NextGen Systems",
    "location": "Hyderabad, India",
    "stipend": "₹7,000/month",
    "duration": "3 Months",
    "postedBy": "65f1a1c2b4a1234567890010",
    "applicants": []
  }
]


const dburl = 'mongodb://127.0.0.1:27017/Alumni';

const saveDate = async()=>{
    try{
        await mongoose.connect(dburl);
        console.log("✅ MongoDB Connected");

        await internship.insertMany(data);
        console.log("All data inserted");

        process.exit();
    }catch(err){
        console.log(err);
    }
}

saveDate();
import Job from "../models/Job.js";
import mongoose from "mongoose";

const data = [
    {
        title: "Frontend Developer", 
        company: "TechCorp Solutions", 
        location: "Remote", 
        salary: "₹6,00,000 - ₹8,00,000 / year", 
        type: "Full-Time", 
        skill: "Web Development" 
    },
    {
        title: "Backend Engineer", 
        company: "CodeMasters Inc.", 
        location: "Bangalore, India", 
        salary: "₹7,50,000 - ₹10,00,000 / year", 
        type: "Full-Time", 
        skill: "Web Development" 
    },
    {
        title: "Data Scientist", 
        company: "DataWorks", location: "Remote", 
        salary: "₹8,00,000 - ₹12,00,000 / year", 
        type: "Contract", 
        skill: "AI/ML" 
    },
    {
        title: "UI/UX Designer", 
        company: "Creative Minds", 
        location: "Delhi, India",
        salary: "₹5,00,000 - ₹7,00,000 / year", 
        type: "Full-Time", 
        skill: "Design" 
    },
    {
        title: "AI/ML Engineer", 
        company: "NeuroNet Labs", 
        location: "Hyderabad, India", 
        salary: "₹9,00,000 - ₹14,00,000 / year", 
        type: "Full-Time", 
        skill: "AI/ML" 
    },
    {
        title: "DevOps Engineer", 
        company: "Cloudify Tech", 
        location: "Pune, India", 
        salary: "₹8,00,000 - ₹11,00,000 / year", 
        type: "Full-Time", 
        skill: "Cloud & DevOps" 
    },
    {
        title: "Mobile App Developer", 
        company: "AppStudio Pro", 
        location: "Mumbai, India", 
        salary: "₹6,50,000 - ₹9,00,000 / year", 
        type: "Full-Time", 
        skill: "Mobile Development" 
    },
    {
        title: "Cybersecurity Analyst", 
        company: "SecureNet Solutions", 
        location: "Chennai, India", 
        salary: "₹7,00,000 - ₹10,00,000 / year", 
        type: "Full-Time", 
        skill: "Cybersecurity" 
    },
];

const dburl = 'mongodb://127.0.0.1:27017/Alumni';

const saveDate = async()=>{
    try{
        await mongoose.connect(dburl);
        console.log("✅ MongoDB Connected");

        await Job.insertMany(data);
        console.log("All data inserted");

        process.exit();
    }catch(err){
        console.log(err);
    }
}

saveDate();